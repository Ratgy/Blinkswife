# 깜빡넘기기 (BlinkSwipe) v1

전면 카메라로 눈을 두 번 깜빡이면 유튜브 숏츠·인스타 릴스·틱톡을 다음 영상으로 넘겨주는 안드로이드 앱.

## 빌드
1. Android Studio(최신)에서 이 폴더를 Open
2. Gradle Sync가 끝나면 폰을 USB(개발자 옵션 → USB 디버깅)로 연결 후 ▶ Run

## 사용
1. 앱의 "접근성 설정 열기" → 설치된 앱 → 깜빡넘기기 스와이프 → 켜기
2. 앱에서 "시작" (카메라·알림 권한 허용)
3. 숏츠/릴스 열고 폰을 얼굴 앞에 → 빠르게 두 번 깜빡

## 감도 조절
BlinkDetector.kt 상단 숫자
- closedThreshold / openThreshold : 감음·뜸 기준 (안경·작은 눈이면 closed를 0.45 정도로)
- doubleWindowMs : 두 번 깜빡임 사이 허용 시간 (기본 0.8초)
- cooldownMs : 넘긴 뒤 쉬는 시간 (기본 1.5초)
