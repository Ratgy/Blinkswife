package com.blinkswipe.app

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.util.Size
import androidx.annotation.OptIn
import androidx.camera.core.CameraSelector
import androidx.camera.core.ExperimentalGetImage
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetector
import com.google.mlkit.vision.face.FaceDetectorOptions
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/** 전면 카메라로 눈을 계속 지켜보는 백그라운드 서비스 (알림이 떠 있는 동안 작동) */
class BlinkCameraService : LifecycleService() {

    companion object {
        const val ACTION_STOP = "com.blinkswipe.app.STOP"
        private const val CHANNEL_ID = "blink"
        private const val NOTIFICATION_ID = 1
    }

    private lateinit var analysisExecutor: ExecutorService
    private lateinit var faceDetector: FaceDetector
    private var cameraStarted = false

    private val blinkDetector = BlinkDetector(
        onBlink = { BlinkState.blinkCount.value = (BlinkState.blinkCount.value ?: 0) + 1 },
        onDoubleBlink = { handleDoubleBlink() },
    )

    override fun onCreate() {
        super.onCreate()
        analysisExecutor = Executors.newSingleThreadExecutor()
        faceDetector = FaceDetection.getClient(
            FaceDetectorOptions.Builder()
                .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
                .setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_ALL)
                .setMinFaceSize(0.25f)
                .build()
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            != PackageManager.PERMISSION_GRANTED
        ) {
            BlinkState.message.value = "카메라 권한이 없어요"
            stopSelf()
            return START_NOT_STICKY
        }
        startInForeground()
        if (!cameraStarted) startCamera()
        BlinkState.running.value = true
        BlinkState.message.value = "숏츠·릴스를 열고 두 번 깜빡여 보세요"
        return START_NOT_STICKY
    }

    private fun startInForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "눈 깜빡임 감지", NotificationManager.IMPORTANCE_LOW)
        )
        val openPi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stopPi = PendingIntent.getService(
            this, 1, Intent(this, BlinkCameraService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_eye)
            .setContentTitle("깜빡넘기기 작동 중")
            .setContentText("눈을 빠르게 두 번 깜빡이면 다음 영상으로 넘어가요")
            .setOngoing(true)
            .setContentIntent(openPi)
            .addAction(0, "정지", stopPi)
            .build()
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R)
            ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA else 0
        ServiceCompat.startForeground(this, NOTIFICATION_ID, notification, type)
    }

    private fun startCamera() {
        cameraStarted = true
        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            val provider = providerFuture.get()
            val analysis = ImageAnalysis.Builder()
                .setResolutionSelector(
                    ResolutionSelector.Builder()
                        .setResolutionStrategy(
                            ResolutionStrategy(
                                Size(640, 480),
                                ResolutionStrategy.FALLBACK_RULE_CLOSEST_LOWER_THEN_HIGHER
                            )
                        ).build()
                )
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()
            analysis.setAnalyzer(analysisExecutor) { proxy -> analyze(proxy) }
            try {
                provider.unbindAll()
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_FRONT_CAMERA, analysis)
            } catch (e: Exception) {
                BlinkState.message.postValue("카메라를 열 수 없어요: ${e.message}")
                stopSelf()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    @OptIn(ExperimentalGetImage::class)
    private fun analyze(proxy: ImageProxy) {
        val media = proxy.image
        if (media == null) {
            proxy.close(); return
        }
        val now = SystemClock.elapsedRealtime()
        val input = InputImage.fromMediaImage(media, proxy.imageInfo.rotationDegrees)
        faceDetector.process(input)
            .addOnSuccessListener { faces -> // 메인 스레드에서 실행됨
                val face = faces.maxByOrNull { it.boundingBox.width() }
                val l = face?.leftEyeOpenProbability
                val r = face?.rightEyeOpenProbability
                BlinkState.faceFound.value = face != null
                BlinkState.eyeOpen.value = if (l != null && r != null) (l + r) / 2f else -1f
                blinkDetector.update(l, r, now)
            }
            .addOnCompleteListener { proxy.close() }
    }

    private fun handleDoubleBlink() {
        val result = SwipeAccessibilityService.instance?.swipeNext(Prefs.onlyShortform(this))
            ?: SwipeResult.NO_SERVICE
        BlinkState.message.value = when (result) {
            SwipeResult.DONE -> {
                BlinkState.swipeCount.value = (BlinkState.swipeCount.value ?: 0) + 1
                vibrate()
                "넘겼어요!"
            }
            SwipeResult.NOT_TARGET -> "두 번 깜빡임 감지 — 숏폼 앱이 아니라서 넘기지 않았어요"
            SwipeResult.NO_SERVICE -> "접근성 서비스가 꺼져 있어요"
            SwipeResult.FAILED -> "스와이프 실패"
        }
    }

    private fun vibrate() {
        val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            getSystemService(VibratorManager::class.java).defaultVibrator
        } else legacyVibrator()
        vibrator.vibrate(VibrationEffect.createOneShot(40, VibrationEffect.DEFAULT_AMPLITUDE))
    }

    @Suppress("DEPRECATION")
    private fun legacyVibrator(): Vibrator = getSystemService(VIBRATOR_SERVICE) as Vibrator

    override fun onDestroy() {
        BlinkState.running.value = false
        BlinkState.faceFound.value = false
        BlinkState.eyeOpen.value = -1f
        faceDetector.close()
        analysisExecutor.shutdown()
        super.onDestroy()
    }
}
