package com.blinkswipe.app

/**
 * 눈 뜸 확률(0=감음, 1=뜸)을 받아 '깜빡임'과 '두 번 깜빡임'을 판정.
 *
 * - 두 눈이 모두 closedThreshold 아래로 내려갔다가 openThreshold 위로 올라오면 깜빡임 1회
 * - 감고 있던 시간이 너무 길면(maxClosedMs) 그냥 눈 감은 걸로 보고 무시
 * - 깜빡임 2회가 doubleWindowMs 안에 들어오면 '두 번 깜빡임'
 * - 넘긴 직후 cooldownMs 동안은 다시 넘기지 않음 (연속 넘김 방지)
 */
class BlinkDetector(
    private val closedThreshold: Float = 0.35f,
    private val openThreshold: Float = 0.65f,
    private val minClosedMs: Long = 30,
    private val maxClosedMs: Long = 500,
    private val doubleWindowMs: Long = 800,
    private val cooldownMs: Long = 1500,
    private val onBlink: () -> Unit = {},
    private val onDoubleBlink: () -> Unit,
) {
    private var eyesClosed = false
    private var closedAt = 0L
    private var lastBlinkAt = 0L
    private var lastTriggerAt = 0L

    fun update(left: Float?, right: Float?, nowMs: Long) {
        if (left == null || right == null) {
            // 얼굴/눈을 놓치면 진행 중이던 판정은 버림
            eyesClosed = false
            return
        }
        val avg = (left + right) / 2f
        if (!eyesClosed) {
            if (left < closedThreshold && right < closedThreshold) {
                eyesClosed = true
                closedAt = nowMs
            }
        } else if (avg > openThreshold) {
            eyesClosed = false
            val closedFor = nowMs - closedAt
            if (closedFor in minClosedMs..maxClosedMs) registerBlink(nowMs)
        }
    }

    private fun registerBlink(nowMs: Long) {
        if (nowMs - lastTriggerAt < cooldownMs) return
        onBlink()
        if (lastBlinkAt > 0 && nowMs - lastBlinkAt <= doubleWindowMs) {
            lastBlinkAt = 0
            lastTriggerAt = nowMs
            onDoubleBlink()
        } else {
            lastBlinkAt = nowMs
        }
    }
}
