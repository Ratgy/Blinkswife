package com.blinkswipe.app

import android.content.Context
import androidx.lifecycle.MutableLiveData

/** 서비스 ↔ 화면 사이에 상태를 주고받는 게시판 */
object BlinkState {
    val running = MutableLiveData(false)
    val faceFound = MutableLiveData(false)
    val eyeOpen = MutableLiveData(-1f)
    val blinkCount = MutableLiveData(0)
    val swipeCount = MutableLiveData(0)
    val message = MutableLiveData("대기 중")
}

object Prefs {
    private const val NAME = "blinkswipe"
    private const val KEY_ONLY_SHORTFORM = "only_shortform"

    fun onlyShortform(c: Context): Boolean =
        c.getSharedPreferences(NAME, Context.MODE_PRIVATE).getBoolean(KEY_ONLY_SHORTFORM, true)

    fun setOnlyShortform(c: Context, value: Boolean) {
        c.getSharedPreferences(NAME, Context.MODE_PRIVATE).edit()
            .putBoolean(KEY_ONLY_SHORTFORM, value).apply()
    }
}
