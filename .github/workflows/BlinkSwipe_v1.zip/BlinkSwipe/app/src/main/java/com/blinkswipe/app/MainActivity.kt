package com.blinkswipe.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.materialswitch.MaterialSwitch

class MainActivity : AppCompatActivity() {

    private lateinit var tvA11y: TextView

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            if (hasCamera()) startBlinkService()
            else Toast.makeText(this, "카메라 권한이 있어야 눈 깜빡임을 볼 수 있어요", Toast.LENGTH_LONG).show()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvA11y = findViewById(R.id.tvA11y)
        val tvState = findViewById<TextView>(R.id.tvState)
        val tvFace = findViewById<TextView>(R.id.tvFace)
        val tvEye = findViewById<TextView>(R.id.tvEye)
        val tvCounts = findViewById<TextView>(R.id.tvCounts)
        val tvMessage = findViewById<TextView>(R.id.tvMessage)
        val btnA11y = findViewById<Button>(R.id.btnA11y)
        val btnToggle = findViewById<Button>(R.id.btnToggle)
        val swOnly = findViewById<MaterialSwitch>(R.id.swOnlyShortform)

        btnA11y.setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        btnToggle.setOnClickListener {
            if (BlinkState.running.value == true) stopBlinkService() else requestAndStart()
        }
        swOnly.isChecked = Prefs.onlyShortform(this)
        swOnly.setOnCheckedChangeListener { _, checked -> Prefs.setOnlyShortform(this, checked) }

        BlinkState.running.observe(this) { on ->
            btnToggle.text = if (on) "정지" else "2. 시작"
            tvState.text = if (on) "작동 중 · 카메라가 눈을 보고 있어요" else "멈춤"
        }
        BlinkState.faceFound.observe(this) { tvFace.text = if (it) "얼굴: 찾음" else "얼굴: 안 보임" }
        BlinkState.eyeOpen.observe(this) { v ->
            tvEye.text = if (v < 0f) "눈 뜬 정도: -" else "눈 뜬 정도: ${(v * 100).toInt()}%"
        }
        val updateCounts = {
            tvCounts.text = "깜빡임 ${BlinkState.blinkCount.value} · 넘김 ${BlinkState.swipeCount.value}"
        }
        BlinkState.blinkCount.observe(this) { updateCounts() }
        BlinkState.swipeCount.observe(this) { updateCounts() }
        BlinkState.message.observe(this) { tvMessage.text = it }
    }

    override fun onResume() {
        super.onResume()
        tvA11y.text = if (SwipeAccessibilityService.instance != null)
            "접근성 서비스: 켜짐" else "접근성 서비스: 꺼짐 (아래 1번 버튼으로 켜주세요)"
    }

    private fun hasCamera() = ContextCompat.checkSelfPermission(
        this, Manifest.permission.CAMERA
    ) == PackageManager.PERMISSION_GRANTED

    private fun requestAndStart() {
        val needed = buildList {
            add(Manifest.permission.CAMERA)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) add(Manifest.permission.POST_NOTIFICATIONS)
        }
        val missing = needed.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isEmpty()) startBlinkService() else permissionLauncher.launch(missing.toTypedArray())
    }

    private fun startBlinkService() {
        if (SwipeAccessibilityService.instance == null) {
            Toast.makeText(this, "접근성 서비스를 먼저 켜야 넘길 수 있어요", Toast.LENGTH_LONG).show()
        }
        ContextCompat.startForegroundService(this, Intent(this, BlinkCameraService::class.java))
    }

    private fun stopBlinkService() {
        startService(Intent(this, BlinkCameraService::class.java).setAction(BlinkCameraService.ACTION_STOP))
    }
}
