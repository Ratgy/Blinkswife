package com.blinkswipe.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent

enum class SwipeResult { DONE, NOT_TARGET, NO_SERVICE, FAILED }

/** 손가락 대신 화면을 위로 쓸어 올려주는 '대리 손가락' */
class SwipeAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: SwipeAccessibilityService? = null
            private set

        val SHORTFORM_PACKAGES = setOf(
            "com.google.android.youtube",   // 유튜브 (숏츠)
            "com.instagram.android",        // 인스타그램 (릴스)
            "com.zhiliaoapp.musically",     // 틱톡
            "com.ss.android.ugc.trill",     // 틱톡 (아시아)
            "com.facebook.katana",          // 페이스북 (릴스)
        )
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit
    override fun onInterrupt() = Unit

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    fun swipeNext(onlyShortform: Boolean): SwipeResult {
        if (onlyShortform) {
            val pkg = rootInActiveWindow?.packageName?.toString()
            if (pkg == null || pkg !in SHORTFORM_PACKAGES) return SwipeResult.NOT_TARGET
        }
        val dm = resources.displayMetrics
        val w = dm.widthPixels.toFloat()
        val h = dm.heightPixels.toFloat()
        val path = Path().apply {
            moveTo(w * 0.5f, h * 0.72f)
            lineTo(w * 0.5f, h * 0.28f)
        }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0L, 220L))
            .build()
        return if (dispatchGesture(gesture, null, null)) SwipeResult.DONE else SwipeResult.FAILED
    }
}
