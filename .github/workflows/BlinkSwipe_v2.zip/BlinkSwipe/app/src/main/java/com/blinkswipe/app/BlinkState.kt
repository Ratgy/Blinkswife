package com.blinkswipe.app

import android.content.Context
import androidx.lifecycle.MutableLiveData

/** 넘기는 방법(트리거) 목록 */
enum class Trigger(val key: String, val label: String, val short: String, val defaultOn: Boolean) {
    BLINK("t_blink", "눈 두 번 깜빡이기", "깜빡임", true),
    MOUTH("t_mouth", "입 크게 벌리기 (0.4초)", "입", false),
    NOD("t_nod", "고개 끄덕이기", "끄덕임", false),
    VOICE("t_voice", "“다음” 말하기", "음성", false),
    SHAKE("t_shake", "폰 한 번 흔들기", "흔들기", false),
    WAVE("t_wave", "화면 위 손 휘젓기 (근접센서·실험)", "손 휘젓기", false),
    VOLUME("t_volume", "볼륨 올리기 = 넘기기 (버즈 길게 누르기·실험)", "볼륨", false);

    val usesCamera: Boolean get() = this == BLINK || this == MOUTH || this == NOD
}

/** 서비스 ↔ 화면 사이에 상태를 주고받는 게시판 */
object BlinkState {
    val running = MutableLiveData(false)
    val faceFound = MutableLiveData(false)
    val eyeOpen = MutableLiveData(-1f)
    val mouthOpen = MutableLiveData(-1f)
    val pitch = MutableLiveData(Float.NaN)
    val blinkCount = MutableLiveData(0)
    val swipeCount = MutableLiveData(0)
    val message = MutableLiveData("대기 중")
}

object Prefs {
    private const val NAME = "blinkswipe"
    private const val KEY_ONLY_SHORTFORM = "only_shortform"

    private fun sp(c: Context) = c.getSharedPreferences(NAME, Context.MODE_PRIVATE)

    fun isOn(c: Context, t: Trigger): Boolean = sp(c).getBoolean(t.key, t.defaultOn)
    fun set(c: Context, t: Trigger, on: Boolean) = sp(c).edit().putBoolean(t.key, on).apply()

    fun onlyShortform(c: Context): Boolean = sp(c).getBoolean(KEY_ONLY_SHORTFORM, true)
    fun setOnlyShortform(c: Context, value: Boolean) =
        sp(c).edit().putBoolean(KEY_ONLY_SHORTFORM, value).apply()
}
