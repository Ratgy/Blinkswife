package com.blinkswipe.app

import android.hardware.SensorManager
import kotlin.math.abs
import kotlin.math.sqrt

/**
 * 두 번 깜빡임: 두 눈이 closed 아래로 감겼다가 open 위로 뜨면 1회.
 * 0.8초 안에 2회면 넘김. 0.5초 넘게 감으면 졸린 걸로 보고 무시.
 */
class BlinkDetector(
    private val closedThreshold: Float = 0.35f,
    private val openThreshold: Float = 0.65f,
    private val minClosedMs: Long = 30,
    private val maxClosedMs: Long = 500,
    private val doubleWindowMs: Long = 800,
    private val onBlink: () -> Unit = {},
    private val onDoubleBlink: () -> Unit,
) {
    private var eyesClosed = false
    private var closedAt = 0L
    private var lastBlinkAt = 0L

    fun update(left: Float?, right: Float?, nowMs: Long) {
        if (left == null || right == null) { eyesClosed = false; return }
        val avg = (left + right) / 2f
        if (!eyesClosed) {
            if (left < closedThreshold && right < closedThreshold) {
                eyesClosed = true; closedAt = nowMs
            }
        } else if (avg > openThreshold) {
            eyesClosed = false
            if (nowMs - closedAt in minClosedMs..maxClosedMs) {
                onBlink()
                if (lastBlinkAt > 0 && nowMs - lastBlinkAt <= doubleWindowMs) {
                    lastBlinkAt = 0; onDoubleBlink()
                } else lastBlinkAt = nowMs
            }
        }
    }

    fun reset() { eyesClosed = false; lastBlinkAt = 0 }
}

/**
 * 입 벌리기: 윗입술~아랫입술 거리 / 얼굴 높이 비율이 openRatio를 holdMs 이상 넘으면 넘김.
 * 말할 때 잠깐 벌어지는 건 holdMs로 걸러짐. 한 번 넘긴 뒤엔 입을 다물어야 다시 작동.
 */
class MouthDetector(
    private val openRatio: Float = 0.12f,
    private val closeRatio: Float = 0.06f,
    private val holdMs: Long = 400,
    private val onTrigger: () -> Unit,
) {
    private var openSince = 0L
    private var armed = true

    fun update(ratio: Float?, nowMs: Long) {
        if (ratio == null) { openSince = 0; return }
        if (ratio > openRatio) {
            if (openSince == 0L) openSince = nowMs
            if (armed && nowMs - openSince >= holdMs) { armed = false; onTrigger() }
        } else {
            openSince = 0
            if (ratio < closeRatio) armed = true
        }
    }

    fun reset() { openSince = 0; armed = true }
}

/**
 * 고개 끄덕임: 평소 고개 각도(기준)를 천천히 따라가다가,
 * 기준보다 downDeg 이상 숙였다가 1초 안에 다시 들면 넘김.
 * 누워 있어도 '평소 각도' 대비로 보기 때문에 자세와 상관없이 작동.
 */
class NodDetector(
    private val downDeg: Float = 12f,
    private val backDeg: Float = 5f,
    private val maxNodMs: Long = 1000,
    private val onTrigger: () -> Unit,
) {
    private var baseline: Float? = null
    private var downAt = 0L

    fun update(pitch: Float?, nowMs: Long) {
        if (pitch == null) { downAt = 0; return }
        val base = baseline ?: pitch.also { baseline = it }
        if (downAt == 0L) {
            if (pitch < base - downDeg) downAt = nowMs
            else baseline = base + (pitch - base) * 0.05f
        } else {
            val elapsed = nowMs - downAt
            if (pitch > base - backDeg) {
                downAt = 0
                if (elapsed <= maxNodMs) onTrigger()
            } else if (elapsed > maxNodMs) {
                downAt = 0; baseline = pitch // 숙인 채로 있으면 그게 새 기준
            }
        }
    }

    fun reset() { baseline = null; downAt = 0 }
}

/** 폰 흔들기: 중력을 뺀 흔들림이 threshold를 넘는 순간이 0.6초 안에 2번이면 넘김 */
class ShakeDetector(
    private val threshold: Float = 11f,
    private val windowMs: Long = 600,
    private val onTrigger: () -> Unit,
) {
    private var peaks = 0
    private var firstPeakAt = 0L
    private var lastPeakAt = 0L

    fun update(x: Float, y: Float, z: Float, nowMs: Long) {
        val force = abs(sqrt(x * x + y * y + z * z) - SensorManager.GRAVITY_EARTH)
        if (force > threshold && nowMs - lastPeakAt > 100) {
            if (nowMs - firstPeakAt > windowMs) { firstPeakAt = nowMs; peaks = 0 }
            peaks++; lastPeakAt = nowMs
            if (peaks >= 2) { peaks = 0; firstPeakAt = 0; onTrigger() }
        }
    }

    fun reset() { peaks = 0; firstPeakAt = 0; lastPeakAt = 0 }
}

/** 손 휘젓기: 근접센서가 '가까움'이 됐다가 0.8초 안에 다시 '멂'이 되면 넘김 */
class WaveDetector(
    private val maxCoverMs: Long = 800,
    private val onTrigger: () -> Unit,
) {
    private var nearAt = 0L

    fun update(near: Boolean, nowMs: Long) {
        if (near) {
            if (nearAt == 0L) nearAt = nowMs
        } else if (nearAt != 0L) {
            val covered = nowMs - nearAt
            nearAt = 0
            if (covered in 50..maxCoverMs) onTrigger()
        }
    }

    fun reset() { nearAt = 0 }
}
