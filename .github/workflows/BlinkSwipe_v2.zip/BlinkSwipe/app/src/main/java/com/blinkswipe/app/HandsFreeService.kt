package com.blinkswipe.app

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.PointF
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.media.AudioManager
import android.os.Build
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.util.Size
import androidx.annotation.OptIn
import androidx.camera.core.CameraSelector
import androidx.camera.core.ExperimentalGetImage
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.Face
import com.google.mlkit.vision.face.FaceContour
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetector
import com.google.mlkit.vision.face.FaceDetectorOptions
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService
import org.vosk.android.StorageService
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.hypot

/** 고른 방법(카메라·마이크·센서·볼륨)을 켜두고, 신호가 오면 다음 영상으로 넘기는 서비스 */
class HandsFreeService : LifecycleService(), SensorEventListener {

    companion object {
        const val ACTION_STOP = "com.blinkswipe.app.STOP"
        const val ACTION_RELOAD = "com.blinkswipe.app.RELOAD"
        private const val CHANNEL_ID = "handsfree"
        private const val NOTIFICATION_ID = 1
        private const val GLOBAL_COOLDOWN_MS = 1200L // 여러 방법이 동시에 걸려도 한 번만 넘김
    }

    private lateinit var analysisExecutor: ExecutorService
    private var enabled: Set<Trigger> = emptySet()
    private var lastTriggerAt = 0L

    // 카메라
    private var faceDetector: FaceDetector? = null
    private var cameraProvider: ProcessCameraProvider? = null

    // 센서
    private var sensorManager: SensorManager? = null
    private var proximityMax = 5f

    // 음성
    private var voskModel: Model? = null
    private var speech: SpeechService? = null

    // 볼륨
    private var volumeReceiver: BroadcastReceiver? = null
    private var volumeHoldUntil = 0L
    private var volumeRestoreTo = 0

    private val blink = BlinkDetector(
        onBlink = { BlinkState.blinkCount.value = (BlinkState.blinkCount.value ?: 0) + 1 },
        onDoubleBlink = { fire(Trigger.BLINK) },
    )
    private val mouth = MouthDetector { fire(Trigger.MOUTH) }
    private val nod = NodDetector { fire(Trigger.NOD) }
    private val shake = ShakeDetector { fire(Trigger.SHAKE) }
    private val wave = WaveDetector { fire(Trigger.WAVE) }

    override fun onCreate() {
        super.onCreate()
        analysisExecutor = Executors.newSingleThreadExecutor()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }

        stopComponents()
        val skipped = mutableListOf<String>()
        enabled = Trigger.values().filter { Prefs.isOn(this, it) }.filter { t ->
            val ok = when {
                t.usesCamera -> granted(Manifest.permission.CAMERA)
                t == Trigger.VOICE -> granted(Manifest.permission.RECORD_AUDIO)
                else -> true
            }
            if (!ok) skipped += t.short
            ok
        }.toSet()

        startInForeground()
        if (enabled.isEmpty()) {
            BlinkState.message.value = "켜진 넘기기 방법이 없어요"
            stopSelf()
            return START_NOT_STICKY
        }
        startComponents()
        BlinkState.running.value = true
        BlinkState.message.value = if (skipped.isEmpty())
            "준비 완료: ${enabled.joinToString(" · ") { it.short }}"
        else "권한이 없어 꺼진 방법: ${skipped.joinToString(", ")}"
        return START_NOT_STICKY
    }

    private fun granted(p: String) =
        ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    // ───────── 알림 · 포그라운드 ─────────

    private fun startInForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "손 안 대고 넘기기", NotificationManager.IMPORTANCE_LOW)
        )
        val openPi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stopPi = PendingIntent.getService(
            this, 1, Intent(this, HandsFreeService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val text = if (enabled.isEmpty()) "준비 중" else enabled.joinToString(" · ") { it.short }
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_eye)
            .setContentTitle("깜빡넘기기 작동 중")
            .setContentText(text)
            .setOngoing(true)
            .setContentIntent(openPi)
            .addAction(0, "정지", stopPi)
            .build()

        var type = 0
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (enabled.any { it.usesCamera }) type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA
            if (Trigger.VOICE in enabled) type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
        }
        ServiceCompat.startForeground(this, NOTIFICATION_ID, notification, type)
    }

    // ───────── 켜기 · 끄기 ─────────

    private fun startComponents() {
        if (enabled.any { it.usesCamera }) startCamera()
        if (Trigger.VOICE in enabled) startVoice()
        if (Trigger.SHAKE in enabled || Trigger.WAVE in enabled) startSensors()
        if (Trigger.VOLUME in enabled) startVolumeWatch()
    }

    private fun stopComponents() {
        cameraProvider?.unbindAll()
        faceDetector?.close()
        faceDetector = null
        speech?.let { it.stop(); it.shutdown() }
        speech = null
        sensorManager?.unregisterListener(this)
        volumeReceiver?.let { runCatching { unregisterReceiver(it) } }
        volumeReceiver = null
        blink.reset(); mouth.reset(); nod.reset(); shake.reset(); wave.reset()
        BlinkState.faceFound.value = false
        BlinkState.eyeOpen.value = -1f
        BlinkState.mouthOpen.value = -1f
        BlinkState.pitch.value = Float.NaN
    }

    // ───────── 카메라: 깜빡임 · 입 · 끄덕임 ─────────

    private fun startCamera() {
        val detector = FaceDetection.getClient(
            FaceDetectorOptions.Builder()
                .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
                .setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_ALL)
                .setContourMode(
                    if (Trigger.MOUTH in enabled) FaceDetectorOptions.CONTOUR_MODE_ALL
                    else FaceDetectorOptions.CONTOUR_MODE_NONE
                )
                .setMinFaceSize(0.25f)
                .build()
        )
        faceDetector = detector
        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            if (faceDetector !== detector) return@addListener // 그사이 설정이 바뀜
            val provider = providerFuture.get()
            cameraProvider = provider
            val analysis = ImageAnalysis.Builder()
                .setResolutionSelector(
                    ResolutionSelector.Builder()
                        .setResolutionStrategy(
                            ResolutionStrategy(
                                Size(640, 480),
                                ResolutionStrategy.FALLBACK_RULE_CLOSEST_LOWER_THEN_HIGHER
                            )
                        ).build()
                )
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()
            analysis.setAnalyzer(analysisExecutor) { proxy -> analyze(proxy, detector) }
            try {
                provider.unbindAll()
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_FRONT_CAMERA, analysis)
            } catch (e: Exception) {
                BlinkState.message.postValue("카메라를 열 수 없어요: ${e.message}")
            }
        }, ContextCompat.getMainExecutor(this))
    }

    @OptIn(ExperimentalGetImage::class)
    private fun analyze(proxy: ImageProxy, detector: FaceDetector) {
        val media = proxy.image
        if (media == null || faceDetector !== detector) { proxy.close(); return }
        val now = SystemClock.elapsedRealtime()
        val input = InputImage.fromMediaImage(media, proxy.imageInfo.rotationDegrees)
        try {
            detector.process(input)
                .addOnSuccessListener { faces -> onFaces(faces, now) } // 메인 스레드
                .addOnCompleteListener { proxy.close() }
        } catch (e: Exception) {
            proxy.close()
        }
    }

    private fun onFaces(faces: List<Face>, now: Long) {
        val face = faces.maxByOrNull { it.boundingBox.width() }
        val l = face?.leftEyeOpenProbability
        val r = face?.rightEyeOpenProbability
        val mouthRatio = face?.let { mouthOpenRatio(it) }
        val pitch = face?.headEulerAngleX

        BlinkState.faceFound.value = face != null
        BlinkState.eyeOpen.value = if (l != null && r != null) (l + r) / 2f else -1f
        BlinkState.mouthOpen.value = mouthRatio ?: -1f
        BlinkState.pitch.value = pitch ?: Float.NaN

        if (Trigger.BLINK in enabled) blink.update(l, r, now)
        if (Trigger.MOUTH in enabled) mouth.update(mouthRatio, now)
        if (Trigger.NOD in enabled) nod.update(pitch, now)
    }

    /** 윗입술 아래선 가운데 ~ 아랫입술 윗선 가운데 거리 / 얼굴 높이 */
    private fun mouthOpenRatio(face: Face): Float? {
        val upper = face.getContour(FaceContour.UPPER_LIP_BOTTOM)?.points
        val lower = face.getContour(FaceContour.LOWER_LIP_TOP)?.points
        if (upper.isNullOrEmpty() || lower.isNullOrEmpty()) return null
        val u: PointF = upper[upper.size / 2]
        val d: PointF = lower[lower.size / 2]
        val h = face.boundingBox.height().toFloat()
        if (h <= 0f) return null
        return hypot(d.x - u.x, d.y - u.y) / h // 누워서 화면이 돌아가도 거리로 계산
    }

    // ───────── 음성: "다음" ─────────

    private fun startVoice() {
        val model = voskModel
        if (model != null) { startSpeech(model); return }
        BlinkState.message.value = "음성 모델 준비 중… (처음 한 번만 조금 걸려요)"
        StorageService.unpack(this, "model-ko", "model",
            { m ->
                voskModel = m
                if (Trigger.VOICE in enabled && speech == null) startSpeech(m)
            },
            { e -> BlinkState.message.value = "음성 모델을 불러오지 못했어요: ${e.message}" }
        )
    }

    private fun startSpeech(model: Model) {
        try {
            val recognizer = Recognizer(model, 16000f, "[\"다음\", \"넘겨\", \"[unk]\"]")
            speech = SpeechService(recognizer, 16000f).also { it.startListening(voiceListener) }
            BlinkState.message.value = "“다음”이라고 말해 보세요"
        } catch (e: Exception) {
            BlinkState.message.value = "마이크를 열 수 없어요: ${e.message}"
        }
    }

    private val voiceListener = object : RecognitionListener {
        override fun onPartialResult(hypothesis: String?) = Unit
        override fun onResult(hypothesis: String?) = handleVoice(hypothesis)
        override fun onFinalResult(hypothesis: String?) = handleVoice(hypothesis)
        override fun onError(exception: Exception?) {
            BlinkState.message.value = "음성 인식 오류: ${exception?.message}"
        }
        override fun onTimeout() = Unit
    }

    private fun handleVoice(json: String?) {
        val text = json?.let { runCatching { JSONObject(it).optString("text") }.getOrNull() } ?: return
        if (text.contains("다음") || text.contains("넘겨")) fire(Trigger.VOICE)
    }

    // ───────── 센서: 흔들기 · 손 휘젓기 ─────────

    private fun startSensors() {
        val sm = getSystemService(SensorManager::class.java)
        sensorManager = sm
        if (Trigger.SHAKE in enabled) {
            sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)?.let {
                sm.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME)
            }
        }
        if (Trigger.WAVE in enabled) {
            val p = sm.getDefaultSensor(Sensor.TYPE_PROXIMITY)
            if (p == null) BlinkState.message.value = "이 폰은 근접센서를 쓸 수 없어요"
            else {
                proximityMax = p.maximumRange
                sm.registerListener(this, p, SensorManager.SENSOR_DELAY_NORMAL)
            }
        }
    }

    override fun onSensorChanged(event: SensorEvent) {
        val now = SystemClock.elapsedRealtime()
        when (event.sensor.type) {
            Sensor.TYPE_ACCELEROMETER ->
                shake.update(event.values[0], event.values[1], event.values[2], now)
            Sensor.TYPE_PROXIMITY ->
                wave.update(event.values[0] < minOf(proximityMax, 5f), now)
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit

    // ───────── 볼륨: 버즈 길게 누르기 · 볼륨키 ─────────

    private fun startVolumeWatch() {
        val am = getSystemService(AudioManager::class.java)
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, i: Intent?) {
                if (i == null) return
                if (i.getIntExtra("android.media.EXTRA_VOLUME_STREAM_TYPE", -1) != AudioManager.STREAM_MUSIC) return
                val v = i.getIntExtra("android.media.EXTRA_VOLUME_STREAM_VALUE", -1)
                val prev = i.getIntExtra("android.media.EXTRA_PREV_VOLUME_STREAM_VALUE", -1)
                if (v < 0 || prev < 0) return
                val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                val wentUp = v > prev || (v == prev && v == max)
                if (!wentUp) return // 내리기는 그대로 둠 (우리가 되돌린 것도 '내림'이라 여기서 걸러짐)

                val now = SystemClock.elapsedRealtime()
                if (now < volumeHoldUntil) {
                    // 길게 눌러 연속으로 올라가는 중: 원래 볼륨으로만 되돌림
                    am.setStreamVolume(AudioManager.STREAM_MUSIC, volumeRestoreTo, 0)
                    volumeHoldUntil = now + 600
                    return
                }
                volumeRestoreTo = prev
                volumeHoldUntil = now + 600
                if (v != prev) am.setStreamVolume(AudioManager.STREAM_MUSIC, prev, 0)
                fire(Trigger.VOLUME)
            }
        }
        volumeReceiver = receiver
        ContextCompat.registerReceiver(
            this, receiver, IntentFilter("android.media.VOLUME_CHANGED_ACTION"),
            ContextCompat.RECEIVER_EXPORTED
        )
    }

    // ───────── 넘기기 ─────────

    private fun fire(t: Trigger) {
        val now = SystemClock.elapsedRealtime()
        if (now - lastTriggerAt < GLOBAL_COOLDOWN_MS) return
        lastTriggerAt = now
        val result = SwipeAccessibilityService.instance?.swipeNext(Prefs.onlyShortform(this))
            ?: SwipeResult.NO_SERVICE
        BlinkState.message.value = when (result) {
            SwipeResult.DONE -> {
                BlinkState.swipeCount.value = (BlinkState.swipeCount.value ?: 0) + 1
                vibrate()
                "${t.short} → 넘겼어요!"
            }
            SwipeResult.NOT_TARGET -> "${t.short} 감지 — 숏폼 앱이 아니라서 넘기지 않았어요"
            SwipeResult.NO_SERVICE -> "접근성 서비스가 꺼져 있어요"
            SwipeResult.FAILED -> "스와이프 실패"
        }
    }

    private fun vibrate() {
        val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            getSystemService(VibratorManager::class.java).defaultVibrator
        } else legacyVibrator()
        vibrator.vibrate(VibrationEffect.createOneShot(40, VibrationEffect.DEFAULT_AMPLITUDE))
    }

    @Suppress("DEPRECATION")
    private fun legacyVibrator(): Vibrator = getSystemService(VIBRATOR_SERVICE) as Vibrator

    override fun onDestroy() {
        stopComponents()
        voskModel?.close()
        voskModel = null
        analysisExecutor.shutdown()
        BlinkState.running.value = false
        super.onDestroy()
    }
}
