package com.blinkswipe.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.materialswitch.MaterialSwitch

class MainActivity : AppCompatActivity() {

    private lateinit var tvA11y: TextView
    private lateinit var tvDebug: TextView

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            startOrReload()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvA11y = findViewById(R.id.tvA11y)
        tvDebug = findViewById(R.id.tvEye)
        val tvState = findViewById<TextView>(R.id.tvState)
        val tvFace = findViewById<TextView>(R.id.tvFace)
        val tvCounts = findViewById<TextView>(R.id.tvCounts)
        val tvMessage = findViewById<TextView>(R.id.tvMessage)
        val btnA11y = findViewById<Button>(R.id.btnA11y)
        val btnToggle = findViewById<Button>(R.id.btnToggle)
        val swOnly = findViewById<MaterialSwitch>(R.id.swOnlyShortform)
        val triggerList = findViewById<LinearLayout>(R.id.triggerList)

        val minH = (48 * resources.displayMetrics.density).toInt()
        Trigger.values().forEach { t ->
            val sw = MaterialSwitch(this)
            sw.text = t.label
            sw.minHeight = minH
            sw.isChecked = Prefs.isOn(this, t)
            sw.setOnCheckedChangeListener { _, checked ->
                Prefs.set(this, t, checked)
                if (BlinkState.running.value == true) requestAndRun()
            }
            triggerList.addView(
                sw, LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
                )
            )
        }

        btnA11y.setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        btnToggle.setOnClickListener {
            if (BlinkState.running.value == true) stopService() else requestAndRun()
        }
        swOnly.isChecked = Prefs.onlyShortform(this)
        swOnly.setOnCheckedChangeListener { _, checked -> Prefs.setOnlyShortform(this, checked) }

        BlinkState.running.observe(this) { on ->
            btnToggle.text = if (on) "정지" else "2. 시작"
            tvState.text = if (on) "작동 중" else "멈춤"
        }
        BlinkState.faceFound.observe(this) { tvFace.text = if (it) "얼굴: 찾음" else "얼굴: 안 보임" }
        BlinkState.eyeOpen.observe(this) { updateDebug() }
        BlinkState.mouthOpen.observe(this) { updateDebug() }
        BlinkState.pitch.observe(this) { updateDebug() }
        val updateCounts = {
            tvCounts.text = "깜빡임 ${BlinkState.blinkCount.value} · 넘김 ${BlinkState.swipeCount.value}"
        }
        BlinkState.blinkCount.observe(this) { updateCounts() }
        BlinkState.swipeCount.observe(this) { updateCounts() }
        BlinkState.message.observe(this) { tvMessage.text = it }
    }

    /** 감도 조절용 실시간 숫자: 눈 뜬 정도 · 입 벌림 · 고개 각도 */
    private fun updateDebug() {
        val eye = BlinkState.eyeOpen.value ?: -1f
        val mouth = BlinkState.mouthOpen.value ?: -1f
        val pitch = BlinkState.pitch.value ?: Float.NaN
        val e = if (eye < 0f) "-" else "${(eye * 100).toInt()}%"
        val m = if (mouth < 0f) "-" else "${(mouth * 100).toInt()}%"
        val p = if (pitch.isNaN()) "-" else "${pitch.toInt()}°"
        tvDebug.text = "눈 $e · 입 $m · 고개 $p"
    }

    override fun onResume() {
        super.onResume()
        tvA11y.text = if (SwipeAccessibilityService.instance != null)
            "접근성 서비스: 켜짐" else "접근성 서비스: 꺼짐 (아래 1번 버튼으로 켜주세요)"
    }

    private fun neededPermissions(): List<String> = buildList {
        if (Trigger.values().any { it.usesCamera && Prefs.isOn(this@MainActivity, it) })
            add(Manifest.permission.CAMERA)
        if (Prefs.isOn(this@MainActivity, Trigger.VOICE)) add(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
            add(Manifest.permission.POST_NOTIFICATIONS)
    }

    private fun requestAndRun() {
        val missing = neededPermissions().filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isEmpty()) startOrReload() else permissionLauncher.launch(missing.toTypedArray())
    }

    private fun startOrReload() {
        if (Trigger.values().none { Prefs.isOn(this, it) }) {
            if (BlinkState.running.value == true) stopService()
            Toast.makeText(this, "넘기는 방법을 하나 이상 켜주세요", Toast.LENGTH_SHORT).show()
            return
        }
        if (SwipeAccessibilityService.instance == null) {
            Toast.makeText(this, "접근성 서비스를 먼저 켜야 넘길 수 있어요", Toast.LENGTH_LONG).show()
        }
        val intent = Intent(this, HandsFreeService::class.java)
        if (BlinkState.running.value == true) intent.action = HandsFreeService.ACTION_RELOAD
        ContextCompat.startForegroundService(this, intent)
    }

    private fun stopService() {
        startService(Intent(this, HandsFreeService::class.java).setAction(HandsFreeService.ACTION_STOP))
    }
}
