import java.util.zip.ZipInputStream

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.blinkswipe.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.blinkswipe.app"
        minSdk = 26
        targetSdk = 34
        versionCode = 4
        versionName = "4.0"
        ndk { abiFilters += "arm64-v8a" }
    }
    buildTypes {
        release { isMinifyEnabled = false }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    val camerax = "1.3.4"
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.lifecycle:lifecycle-service:2.8.4")
    implementation("androidx.lifecycle:lifecycle-livedata-ktx:2.8.4")
    implementation("androidx.camera:camera-core:$camerax")
    implementation("androidx.camera:camera-camera2:$camerax")
    implementation("androidx.camera:camera-lifecycle:$camerax")
    // 얼굴·눈 뜸 확률 인식 (모델이 앱에 포함되어 오프라인 동작)
    implementation("com.google.mlkit:face-detection:16.1.7")
    // "다음" 음성 인식 (오프라인)
    implementation("com.alphacephei:vosk-android:0.3.47@aar")
    implementation("net.java.dev.jna:jna:5.13.0@aar")
}

// 한국어 음성 모델을 빌드할 때 자동으로 받아 앱에 넣음 (실패해도 빌드는 계속, 음성만 꺼짐)
val voskModelDir = file("src/main/assets/model-ko")
val downloadVoskModel by tasks.registering {
    doLast {
        if (File(voskModelDir, "uuid").exists()) return@doLast
        try {
            val zipFile = layout.buildDirectory.file("vosk-ko.zip").get().asFile
            zipFile.parentFile.mkdirs()
            uri("https://alphacephei.com/vosk/models/vosk-model-small-ko-0.22.zip").toURL().openStream().use { input ->
                zipFile.outputStream().use { input.copyTo(it) }
            }
            ZipInputStream(zipFile.inputStream()).use { zis: ZipInputStream ->
                var entry = zis.nextEntry
                while (entry != null) {
                    val rel = entry.name.substringAfter('/', "")
                    if (rel.isNotEmpty() && !rel.contains("..")) {
                        val out = File(voskModelDir, rel)
                        if (entry.isDirectory) out.mkdirs()
                        else { out.parentFile.mkdirs(); out.outputStream().use { zis.copyTo(it) } }
                    }
                    entry = zis.nextEntry
                }
            }
            File(voskModelDir, "uuid").writeText("vosk-model-small-ko-0.22")
        } catch (e: Exception) {
            logger.warn("음성 모델 다운로드 실패 — 음성 기능 없이 빌드합니다: ${e.message}")
        }
    }
}
tasks.configureEach {
    if (name == "preBuild") dependsOn(downloadVoskModel)
}
